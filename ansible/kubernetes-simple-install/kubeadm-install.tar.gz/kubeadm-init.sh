#!/bin/bash

# http_proxy=http://192.168.100.188:8123 https_proxy=http://192.168.100.188:8123 no_proxy=191.168.100.0/24 kubeadm init --apiserver-advertise-address=192.168.100.187 --pod-network-cidr=10.10.0.0/16 --ignore-preflight-errors=all
kubeadm init --apiserver-advertise-address=192.168.100.187 --pod-network-cidr=10.10.0.0/16 --ignore-preflight-errors=all
